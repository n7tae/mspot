#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "opendht" for configuration "Release"
set_property(TARGET opendht APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(opendht PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "simdutf::simdutf"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libopendht.so.4.4.0"
  IMPORTED_SONAME_RELEASE "libopendht.so.4"
  )

list(APPEND _cmake_import_check_targets opendht )
list(APPEND _cmake_import_check_files_for_opendht "${_IMPORT_PREFIX}/lib/libopendht.so.4.4.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
